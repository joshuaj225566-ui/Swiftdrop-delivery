
async function fetchTrackingData(){
  try{
    const res = await fetch('tracking.json', {cache: 'no-store'});
    if(!res.ok) throw new Error('No tracking file');
    const data = await res.json();
    return data;
  }catch(e){
    console.error(e);
    return null;
  }
}

function escapeHtml(s){ return String(s).replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#39;"})[m]); }

async function track(){
  const input = document.getElementById('trackingInput');
  const code = input.value.trim();
  const box = document.getElementById('statusBox');
  box.style.display = 'block';
  box.innerHTML = '<div class="meta">Loading...</div>';
  if(!code){ box.innerHTML = '<div class="meta" style="color:#d9534f">Please enter a tracking number.</div>'; return; }
  const data = await fetchTrackingData();
  if(!data){ box.innerHTML = '<div class="meta" style="color:#d9534f">Tracking service unavailable.</div>'; return; }
  const record = data[code];
  if(!record){ box.innerHTML = '<div class="meta" style="color:#d9534f">Tracking number not found.</div>'; return; }
  // render
  let html = '<div class="meta"><strong>Tracking:</strong> ' + escapeHtml(code) + '</div>';
  html += '<div class="meta"><strong>Location:</strong> ' + escapeHtml(record.location || '') + ' &nbsp; <strong>Last update:</strong> ' + escapeHtml(record.last_update || '') + '</div>';
  html += '<div class="timeline">';
  const stages = record.stages || [];
  const idx = Number(record.stage_index) || 0;
  for(let i=0;i<stages.length;i++){
    const cls = (i===idx)?'step current':'step';
    html += '<div class="'+cls+'"><div>' + escapeHtml(stages[i]) + '</div></div>';
  }
  html += '</div>';
  box.innerHTML = html;
}

document.getElementById?.('trackBtn')?.addEventListener('click', track);
document.addEventListener('DOMContentLoaded', function(){
  const btn = document.getElementById('trackBtn');
  const input = document.getElementById('trackingInput');
  if(btn) btn.addEventListener('click', track);
  if(input) input.addEventListener('keydown', function(e){ if(e.key==='Enter'){ track(); }});
});
